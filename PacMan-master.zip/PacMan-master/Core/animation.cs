﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;



namespace PacMan.Core
{
    public class Animation
    {
        public Texture2D spriteSheet;
        private int frameWidth;
        private int frameHeight;
        public int totalFrames;
        public int currentFrame;
        private float frameDuration;
        private float timer;
        private SpriteBatch spriteBatch;



        public Animation(SpriteBatch spriteBatch, Texture2D spriteSheet, int frameWidth, int frameHeight, int totalFrames, float frameDuration)
        {
            this.spriteSheet = spriteSheet;
            this.frameWidth = frameWidth;
            this.frameHeight = frameHeight;
            this.totalFrames = totalFrames;
            this.frameDuration = frameDuration;
            this.currentFrame = 0;
            this.timer = 0f;
            this.spriteBatch = spriteBatch;

        }

        public void Update(GameTime gameTime)
        {
            timer += (float)gameTime.ElapsedGameTime.TotalSeconds;

            if (timer >= frameDuration)
            {
                timer = 0f;
                currentFrame = (currentFrame + 1) % totalFrames;
            }
        }

        public void Draw(Vector2 position, Color color, SpriteEffects effect, int scale)
        {
            int row = currentFrame / (spriteSheet.Width / frameWidth);
            int column = currentFrame % (spriteSheet.Width / frameWidth);

            Rectangle sourceRectangle = new Rectangle(column * frameWidth, row * frameHeight, frameWidth, frameHeight);
            Vector2 destination = new Vector2((int)position.X, (int)position.Y);

            spriteBatch.Draw(spriteSheet, destination, sourceRectangle, color, 0f, Vector2.Zero, scale, effect, 0f);

        }


        public (Texture2D tex, Rectangle rec) GiveCurrentSprite()
        {
            int row = currentFrame / (spriteSheet.Width / frameWidth);
            int column = currentFrame % (spriteSheet.Width / frameWidth);

            Rectangle sourceRectangle = new Rectangle(column * frameWidth, row * frameHeight, frameWidth, frameHeight);

            return (spriteSheet, sourceRectangle);
        }
    }
}
