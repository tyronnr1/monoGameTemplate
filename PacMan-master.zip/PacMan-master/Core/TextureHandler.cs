﻿using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace PacMan.Core
{
    public class TextureHandler
    {
        
        //public static Texture2D PlayerShot;



        public static void LoadTextures(ContentManager content)
        {
            
            //PlayerShot = content.Load<Texture2D>("playershot");


        }
    }
}
