﻿
using var game = new PacMan.Game1();
game.Run();
