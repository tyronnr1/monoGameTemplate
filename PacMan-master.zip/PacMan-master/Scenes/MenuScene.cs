﻿using PacMan.Core;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;

namespace PacMan.Scenes
{
    internal class MenuScene : Component
    {
        internal override void Draw(SpriteBatch spriteBatch)
        {

        }

        internal override void LoadContent(ContentManager Content, SpriteBatch spriteBatch)
        {

        }

        internal override void Update(GameTime gameTime)
        {

        }
    }

}
