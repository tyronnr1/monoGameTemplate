﻿using PacMan.Core;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;

namespace PacMan.Scenes
{

    internal class GameScene : Component
    {
        internal override void Draw(SpriteBatch spriteBatch)
        {

        }

        internal override void LoadContent(ContentManager Content, SpriteBatch spriteBatch)
        {

        }

        internal override void Update(GameTime gameTime)
        {

        }
    }
}